import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//145 strong number :  1! + 4! + 5! = 145 
		// 						1 + 24 + 120 = 145
		
		// accept a number 
		Scanner scanner = new Scanner(System.in);
	//   class  reference ====> will refer the object 
		// new Scanner() ===> it will give u the object.
		// System.in 
		// in : inputstream object ==> will help us to get the value/values from console.
		
		System.out.println("Enter the number");
		int a = scanner.nextInt();
		// scanner.nextInt()
		// do we need to separate the digits .? ===> yes
		int d = 0;
		int fact = 1;
		int sum = 0;
		int temp = a;
		while (a>0) { // termination condition
			d = a % 10; // we are using decimal number system.  it will give u a last digit
			//System.out.println(d);
			
			for(int i = 1; i<=d;i++) {
				fact = fact * i;
			}
			
			System.out.println(fact);
			sum = sum + fact;
			fact = 1;
			a = a / 10; // 0
			
		}
		
		if(temp==sum) {
		System.out.println("number is strong number");
		}
		else {
			System.out.println("number is not strong");
		}
//		System.out.println(a);
	//	System.out.println("Final value"+sum);
		
	}

}


