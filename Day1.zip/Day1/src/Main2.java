import java.util.Scanner;

public class Main2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String ipAddress ;
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("enter ip address");
		ipAddress = scanner.next();
		
		String cells[] = ipAddress.split("\\.");
		// escape ===> \\.====> \. ===> . 
		
		for (String string : cells) {
			System.out.println(Integer.parseInt(string));
			// it will transform string ====> integer
			
		}

	}

}
