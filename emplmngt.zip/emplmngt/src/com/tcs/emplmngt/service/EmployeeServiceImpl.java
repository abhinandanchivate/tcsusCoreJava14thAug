package com.tcs.emplmngt.service;

import com.tcs.emplmngt.dao.EmployeeDAO;
import com.tcs.emplmngt.dao.EmployeeDAOImpl;
import com.tcs.emplmngt.model.Employee;

public class EmployeeServiceImpl implements EmployeeService {
	// we are creating employeeDAO Object.
	EmployeeDAO employeeDAO = new EmployeeDAOImpl();
	

	@Override
	public String addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return employeeDAO.addEmployee(employee);
	}

	@Override
	public String updateEmployee(String empId, Employee employee) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteEmployeeById(String id) {
		// TODO Auto-generated method stub
		return employeeDAO.deleteEmployeeById(id);
	}

	@Override
	public Employee getEmployeeById(String id) {
		// TODO Auto-generated method stub
		return employeeDAO.getEmployeeById(id);
	}

	@Override
	public Employee[] getEmployees() {
		// TODO Auto-generated method stub
		return employeeDAO.getEmployees();
	}

}
