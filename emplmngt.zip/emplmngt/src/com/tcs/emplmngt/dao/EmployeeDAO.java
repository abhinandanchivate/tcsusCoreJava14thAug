package com.tcs.emplmngt.dao;

import com.tcs.emplmngt.model.Employee;

public interface EmployeeDAO {
	
	public String addEmployee(Employee employee);
	public String updateEmployee(String empId, Employee employee);
	public String deleteEmployeeById(String id);
	public Employee getEmployeeById(String id);
	public Employee[] getEmployees();
}
