package com.tcs.emplmngt.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import com.tcs.emplmngt.model.Employee;

public class EmployeeDAOImpl implements EmployeeDAO {

	private Set<Employee> employees = new HashSet<>();

	@Override
	public String addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		boolean result = false;
		try {
			result = employees.add(employee);
			if (result) {
				return "success";
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}
		return "fail";
	}

	@Override
	public String updateEmployee(String empId, Employee employee) {
		// TODO Auto-generated method stub
		return null;
		// assignment
	}

	@Override
	public String deleteEmployeeById(String id) {
		// TODO Auto-generated method stub

		Employee employee = this.getEmployeeById(id);

		if (employee != null) {
			// employee exists
			boolean status = employees.remove(employee);
			if (status) {
				return "success";
			}
		}

		return "fail";
	}

	@Override
	public Employee getEmployeeById(String id) {
		// TODO Auto-generated method stub

		for (Employee employee : employees) {
			System.out.println(employee);
			if (id.equals(employee.getEmployeeId())) {
				return employee;
			}
		}
		return null;

	}

	@Override
	public Employee[] getEmployees() {
		// TODO Auto-generated method stub
		// arraylist to array
		Employee employee[] = new Employee[employees.size()];

		for (Employee employee2 : employees) {
			System.out.println("employee details from getemployees method"+ employee2);
		}
		return employees.toArray(employee);
		// return null;
	}

}
