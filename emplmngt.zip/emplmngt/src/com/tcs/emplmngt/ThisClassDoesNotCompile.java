package com.tcs.emplmngt;

public class ThisClassDoesNotCompile { 
	public static void main(String[] args) {
		byte x = 5; byte y = 10;
		System.out.println(((Object)(x + y)).getClass().getSimpleName());
		
		System.out.println("abhi".equals(x));
	}

}
