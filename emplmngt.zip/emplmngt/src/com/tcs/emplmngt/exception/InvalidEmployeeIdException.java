package com.tcs.emplmngt.exception;

public class InvalidEmployeeIdException extends Exception {
	
	public InvalidEmployeeIdException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);// we will call a base constructor which will accept the string as an arg.
		
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.getMessage();// will return the message which we set it through super method.
	}
	
	

}
