package com.tcs.emplmngt;

import java.util.Scanner;

import com.tcs.emplmngt.exception.InvalidEmployeeIdException;
import com.tcs.emplmngt.model.Employee;
import com.tcs.emplmngt.service.EmployeeService;
import com.tcs.emplmngt.service.EmployeeServiceImpl;

public class Main {

	
	public static void main(String[] args)  {
		
		EmployeeService employeeService = new EmployeeServiceImpl();
		
		Employee employee = null;
		Employee employee3 = null;
		try {
			employee = new Employee("ab00001", "abhi", "chivate");
			String  result = employeeService.addEmployee(employee);
			System.out.println("result "+ result);
			employee3 = new Employee("ab00001", "abhi", "chivate");
			String  result2 = employeeService.addEmployee(employee3);
			System.out.println("result "+ result);
			Employee [] employees = employeeService.getEmployees();
			System.out.println(employees[0]);
			//System.out.println(employees[1]);
			Employee employee2 = employeeService.getEmployeeById("ab00001");
			System.out.println(employee2);
		} catch (InvalidEmployeeIdException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			}
}
